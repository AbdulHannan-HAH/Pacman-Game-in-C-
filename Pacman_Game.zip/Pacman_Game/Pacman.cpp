#include <iostream>
#include <windows.h>
#include <unistd.h>
#include <conio.h>
#include <fstream>

using namespace std;

//Functions
void Play();
void Logo();
int loadScoreFromFile();
void saveScoreToFile(int score);
void Instructions();
void pattern();
void gotoxy(int x, int y);
void erase(int x, int y);
char getCharAtxy(short int x, short int y);
void PrintPacman(int x, int y);
void clear(int x, int y, char previous);
string pattern(string record, int field);
void readpattern();
void printenemy();
void eraseenemy();
void moveenemy();
void moveVerticalEnemy();
void Options();
int Main_Menu();

//Data Structures
const int MAX = 100;
const char PACMAN_CHAR = 'P';
const char ENEMY_CHAR = 'G';
int enemyX = 37;
int enemyY = 9;
int enemyX2 = 24;
int enemyY2 = 5;
char enemy1[1] = {ENEMY_CHAR};
char enemy2[1] = {ENEMY_CHAR};
string enemydirection = "right";
string enemydirection2 = "down";
string readmaze[MAX];
int idx = 0;
int score = 0;
int lives = 3;

int main()
 {
 	
 	 Logo();
 	Options();
    
    return 0;
}

void gotoxy(int x, int y) {
    COORD coordinates;
    coordinates.X = x;
    coordinates.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
}

void erase(int x, int y) {
    gotoxy(x, y);
    cout << " ";
}

char getCharAtxy(short int x, short int y) {
    CHAR_INFO ci;
    COORD xy = {0, 0};
    SMALL_RECT rect = {x, y, x, y};
    COORD coordBufSize;
    coordBufSize.X = 1;
    coordBufSize.Y = 1;
    return ReadConsoleOutput(GetStdHandle(STD_OUTPUT_HANDLE), &ci, coordBufSize, xy, &rect) ? ci.Char.AsciiChar : ' ';
}

void PrintPacman(int x, int y) {
    gotoxy(x, y);
    cout << PACMAN_CHAR;
}

void clear(int x, int y, char previous) {
    gotoxy(x, y);
    cout << previous;
}

void readpattern() {
    string record;
    fstream data;
    data.open("gameMaze.txt", ios::in);
    while (getline(data, record)) {
        readmaze[idx] = pattern(record, 1);
        idx = idx + 1;
    }
    data.close();
}

string pattern(string record, int field) {
    int commaCount = 1;
    string item;
    for (int x = 0; x < record.length(); x++) {
        if (record[x] == ',') {
            commaCount = commaCount + 1;
        } else if (commaCount == field) {
            item = item + record[x];
        }
    }
    return item;
}

void pattern() {
    readpattern();
    for (int i = 0; i < idx; i++) {
        cout << readmaze[i];
        cout << endl;
    }
}

void moveenemy() {
    if (enemydirection == "right") {
        char next = getCharAtxy(enemyX + 1, enemyY);
        if (next == ' ') {
            eraseenemy();
            enemyX = enemyX + 1;
            printenemy();
        }
        if (next == '#' || next == '.'||next=='&') {
            enemydirection = "left";
        }
    } else if (enemydirection == "left") {
        char next = getCharAtxy(enemyX - 1, enemyY);
        if (next == ' ') {
            eraseenemy();
            enemyX = enemyX - 1;
            printenemy();
        }
        if (next == '#' || next == '.'||next=='&') {
            enemydirection = "right";
        }
    }
}

void moveVerticalEnemy() {
    if (enemydirection2 == "down") {
        char next = getCharAtxy(enemyX2, enemyY2 + 1);
        if (next == ' ') {
            eraseenemy();
            enemyY2 = enemyY2 + 1;
            printenemy();
        }
        if (next == '#' || next == '.'||next=='&') {
            enemydirection2 = "up";
        }
    } else if (enemydirection2 == "up") {
        char next = getCharAtxy(enemyX2, enemyY2 - 1);
        if (next == ' ') {
            eraseenemy();
            enemyY2 = enemyY2 - 1;
            printenemy();
        }
        if (next == '#' || next == '.'||next=='&') {
            enemydirection2 = "down";
        }
    }
}

void eraseenemy() {
    gotoxy(enemyX, enemyY);
    cout << " ";
    gotoxy(enemyX2, enemyY2);
    cout << " ";
}

void printenemy() {
    gotoxy(enemyX, enemyY);
    cout << enemy1[0];
    gotoxy(enemyX2, enemyY2);
    cout << enemy2[0];
}
void saveScoreToFile(int score) {
    ofstream file("score.txt", ios::app);
    if (file.is_open()) {
        file << "Score: " << score << endl;
        file.close();
    } else {
        cout << "Unable to save score to file." << endl;
    }
}
int loadScoreFromFile()
 {
    ifstream file("score.txt");
    int savedScore = 0;
    if (file.is_open()) {
        file >> savedScore;
        file.close();
        cout << "Previous score loaded from file." << endl;
    } else {
        cout << "No previous score found." << endl;
    }
    return savedScore;
}
void Instructions()
{
	 	system("Color 02");
	cout<<"--------------->>>>>>>>>>Instructions<<<<<<<<<<---------------"<<endl;
	cout<<"Following are some instructions to play game: "<<endl;
	cout<<"1--->Press left arrow key to move pacman in left direction."<<endl;
	cout<<"2--->Press up arrow key to move pacman in upward direction."<<endl;
	cout<<"3--->Press right arrow key to move pacman in right direction."<<endl;
	cout<<"4--->Press down arrow key to move pacman in downward direction."<<endl;
	cout<<"5--->* represents food pallet."<<endl;
	cout<<"6--->G represents enemy."<<endl;
	cout<<"7--->You have three lives to survive in the game."<<endl;
	cout<<"8--->You have to save pacman from boundary walls(&,#) and enemies(G)."<<endl;
	cout<<"Press any key to continue...."<<endl;
	getch();
}
void Logo()
{
	cout<<"#######################################################################################"<<endl;
	cout<<"#    |%|%|%|%|   %%%%%%%   |%|%|%|%|  |%|          |%|   %%%%%%%   |%|         |%|    #"<<endl;             
	cout<<"#    |%|   |%|  |%|   |%|  |%|        |%| |%|   |%||%|  |%|   |%|  |%| |%|     |%|    #"<<endl;       
	cout<<"#    |%|%|%|%|  |%|%|%|%|  |%|        |%|    |%|   |%|  |%|%|%|%|  |%|   |%|   |%|    #"<<endl;
	cout<<"#    |%|        |%|   |%|  |%|        |%|          |%|  |%|   |%|  |%|     |%| |%|    #"<<endl;
	cout<<"#    |%|        |%|   |%|  |%|%|%|%|  |%|          |%|  |%|   |%|  |%|         |%|    #"<<endl;
    cout<<"#######################################################################################"<<endl;
}

void Play()
{
	system("Color 0E");
    int pacmanX = 4;
    int pacmanY = 4;
    bool gamerunning = true;
    char previous = ' ';

    system("CLS");
    pattern();
    PrintPacman(pacmanX, pacmanY);

    while (gamerunning && lives > 0) {
        moveenemy();
        moveVerticalEnemy();

        if (GetAsyncKeyState(VK_LEFT)) {
            char nextLocation = getCharAtxy(pacmanX - 1, pacmanY);
            if (nextLocation == ' ') {
                erase(pacmanX, pacmanY);
                pacmanX = pacmanX - 1;
                PrintPacman(pacmanX, pacmanY);
            } else if (nextLocation == '&' || nextLocation == '#' || nextLocation == ENEMY_CHAR) {
                gotoxy(32, 20);
                cout << "Lost a Life! Lives Remaining: " << lives - 1;
                lives--;
                Sleep(1000);
            } else if (nextLocation == '.') {
                erase(pacmanX, pacmanY);
                pacmanX = pacmanX - 1;
                score += 1;
                gotoxy(17, 20);
                cout << "Score=" << score;
                PrintPacman(pacmanX, pacmanY);
            } else if (nextLocation == '*') {
                erase(pacmanX, pacmanY);
                pacmanX = pacmanX - 1;
                score += 4;
                gotoxy(17, 20);
                cout << "Score=" << score;
                PrintPacman(pacmanX, pacmanY);
            }
            
        } else if (GetAsyncKeyState(VK_RIGHT)) {
            char nextLocation = getCharAtxy(pacmanX + 1, pacmanY);
            if (nextLocation == ' ') {
                erase(pacmanX, pacmanY);
                pacmanX = pacmanX + 1;
                PrintPacman(pacmanX, pacmanY);
            } else if (nextLocation == '&' || nextLocation == '#' || nextLocation == ENEMY_CHAR) {
                gotoxy(32, 20);
                cout << "Lost a Life! Lives Remaining: " << lives - 1;
                lives--;
                Sleep(1000);
            } else if (nextLocation == '.') {
                erase(pacmanX, pacmanY);
                pacmanX = pacmanX + 1;
                score += 1;
                gotoxy(17, 20);
                cout << "Score=" << score;
                PrintPacman(pacmanX, pacmanY);
            } else if (nextLocation == '*') {
                erase(pacmanX, pacmanY);
                pacmanX = pacmanX + 1;
                score += 4;
                gotoxy(17, 20);
                cout << "Score=" << score;
                PrintPacman(pacmanX, pacmanY);
            }
            
        } else if (GetAsyncKeyState(VK_UP)) {
            char nextLocation = getCharAtxy(pacmanX, pacmanY - 1);
            if (nextLocation == ' ') {
                erase(pacmanX, pacmanY);
                pacmanY = pacmanY - 1;
                PrintPacman(pacmanX, pacmanY);
            } else if (nextLocation == '&' || nextLocation == '#' || nextLocation == ENEMY_CHAR) {
                gotoxy(32, 20);
                cout << "Lost a Life! Lives Remaining: " << lives - 1;
                lives--;
                Sleep(1000);
            } else if (nextLocation == '.') {
                erase(pacmanX, pacmanY);
                pacmanY = pacmanY - 1;
                score += 1;
                gotoxy(17, 20);
                cout << "Score=" << score;
                PrintPacman(pacmanX, pacmanY);
            } else if (nextLocation == '*') {
                erase(pacmanX, pacmanY);
                pacmanY = pacmanY - 1;
                score += 4;
                gotoxy(17, 20);
                cout << "Score=" << score;
                PrintPacman(pacmanX, pacmanY);
            }
            
        } else if (GetAsyncKeyState(VK_DOWN)) {
            char nextLocation = getCharAtxy(pacmanX, pacmanY + 1);
            if (nextLocation == ' ') {
                erase(pacmanX, pacmanY);
                pacmanY = pacmanY + 1;
                PrintPacman(pacmanX, pacmanY);
            } else if (nextLocation == '&' || nextLocation == '#' || nextLocation == ENEMY_CHAR) {
                gotoxy(32, 20);
                cout << "Lost a Life! Lives Remaining: " << lives - 1;
                lives--;
                Sleep(1000);
            } else if (nextLocation == '.') {
                erase(pacmanX, pacmanY);
                pacmanY = pacmanY + 1;
                score += 1;
                gotoxy(17, 20);
                cout << "Score=" << score;
                PrintPacman(pacmanX, pacmanY);
            } else if (nextLocation == '*') {
                erase(pacmanX, pacmanY);
                pacmanY = pacmanY + 1;
                score += 4;
                gotoxy(17, 20);
                cout << "Score=" << score;
                PrintPacman(pacmanX, pacmanY);
            }
            
        } 
        

        Sleep(200);
        
    }

    system("cls");
    sleep(1);
    if (lives == 0) 
	{
		cout<<"*************************"<<endl;
		cout<<"*                       *"<<endl;
		cout<<"*       GAME OVER       *"<<endl;
		cout<<"*                       *"<<endl;
		cout<<"*************************"<<endl;
        cout << "Your Score: " << score << endl;
        cout << "Play Better Next Time";
        saveScoreToFile(score); // Save score to file when the game ends
    } 

}


int Main_Menu()
{
	system("Color 03");
	int op;
	cout<<endl;
	cout<<"^^^^^^^^^^Welcome to Main Menu^^^^^^^^^^ "<<endl;
	cout<<"1--->Start Game"<<endl;
	cout<<"2--->Instructions"<<endl;
	cout<<"3--->Exit Game"<<endl;
	cout<<"Choose an option from the above given options:"<<endl;
	cin>>op;
	return op;
}
void Options()
{
	int choice=0;
	while(choice!=3)
	{
		choice=Main_Menu();
		if(choice==1)
		{
			Play();
			cout<<endl;
			sleep(4);

			system ("CLS");
			
			Logo();
		}
		else if(choice==2)
		{
			system ("CLS");
			Logo();
			Instructions();
			system("CLS");
			Logo();
		}
		else if(choice==3)
		{
			system ("Color 0E");
			system("CLS");
			Logo();
			cout<<"Thanks for playing. Good Bye!"<<endl;
			break;
		
		}
		else{
			cout<<"You have entered wrong information."<<endl;
		}
	}
}

